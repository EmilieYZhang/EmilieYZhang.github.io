const startButton = document.getElementById("start-button")
const instructions = document.getElementById("instructions-text")
const mainPlayArea = document.getElementById("main-play-area")
const shooter = document.getElementById("player-controlled-shooter")
const monsterImgs = ['images/blood.png']
//here is the monster image
const scoreCounter = document.querySelector('#shotMonsters span')
const healthIndicator = document.querySelector('#health span')

var monsterInterval
var health = parseInt(healthIndicator.innerText)
var healthIncrement = 5
// increased or decreased by 5%
var monsterCount = 0
// count how many monsters will be created. 20 in the case
var dead = 0
// total comsumed monsters; this includes killed monsters and monsters who've exited the screen. it's to calculate whether or not the player has won.
const allMonsters = 25
//if you want to change the amount of monsters generated, then change the preceding line
startButton.addEventListener("click", (event) => {
  playGame()
})


function letShipFly(event) {
  if (event.key === "ArrowUp") {
    event.preventDefault()
    moveUp()
  } else if (event.key === "ArrowDown") {
    event.preventDefault()
    moveDown()
  } else if (event.key === " ") {
    event.preventDefault()
    fireLaser()
  }
}


function moveUp() {
  let topPosition = window.getComputedStyle(shooter).getPropertyValue('top')
  if (shooter.style.top === "0px") {
    return
  } else {
    let position = parseInt(topPosition)
    position -= 10
    shooter.style.top = `${position}px`
  }
}


function moveDown() {
  let topPosition = window.getComputedStyle(shooter).getPropertyValue('top')
  if (shooter.style.top === "360px") {
    return
  } else {
    let position = parseInt(topPosition)
    position += 10
    shooter.style.top = `${position}px`
  }
}


function fireLaser() {
  let laser = createLaserElement()
  mainPlayArea.appendChild(laser)
  moveLaser(laser)
}


function createLaserElement() {
  let xPosition = parseInt(window.getComputedStyle(shooter).getPropertyValue('left'))
  let yPosition = parseInt(window.getComputedStyle(shooter).getPropertyValue('top'))
  let newLaser = document.createElement('img')
  newLaser.src = 'images/laser.png'
	//here is the image for what the player will shoot out at the monsters
  newLaser.classList.add('laser')
  newLaser.style.left = `${xPosition}px`
  newLaser.style.top = `${yPosition - 10}px`
  return newLaser
}


function moveLaser(laser) {
  let laserInterval = setInterval(() => {
    let xPosition = parseInt(laser.style.left)
    let monsters = document.querySelectorAll(".monster")
    monsters.forEach(monster => {
      if (checkLaserCollision(laser, monster)) {
        monster.src = "images/explosion.png"
				//here is what happens when you shoot a monster...an explosion
        monster.classList.remove("monster")
        monster.classList.add("dead-monster")
        scoreCounter.innerText = parseInt(scoreCounter.innerText) + 1
				//idk if you want regeneration but everytime you shoot a monster, it regenerates. if you dont want regeneration then remove the following line of code
        if (health >= 100) {
          health = 100
        }
        healthIndicator.innerText = health
      }
    })
    if (xPosition === 740) {
      laser.remove()
    } else {
      laser.style.left = `${xPosition + 4}px`
    }
  }, 10)
}


function createMonster() {
  let newMonster = document.createElement('img')
  let monsterSpriteImg = monsterImgs[Math.floor(Math.random()*monsterImgs.length)]
  newMonster.src = monsterSpriteImg
  newMonster.classList.add('monster')
  newMonster.classList.add('monster-transition')
  newMonster.style.left = '770px'
  newMonster.style.top = `${Math.floor(Math.random() * 330) + 30}px`
  mainPlayArea.appendChild(newMonster)
  moveMonster(newMonster)
}


function moveMonster(monster) {
  let moveMonsterInterval = setInterval(() => {
    let xPosition = parseInt(window.getComputedStyle(monster).getPropertyValue('left'))
    if (xPosition <= 50) {
			if (monster.classList.contains("dead-monster") == false) { // a dead monster does not reduce health
				health = healthIndicator.innerText - 	healthIncrement
      	healthIndicator.innerText = health
			}
      monster.remove()
      dead += 1
      if (health <= 0 || dead >= allMonsters) {
        gameOver()
      }
    } else {
      monster.style.left = `${xPosition - 4}px`
    }
  }, 30)
}


function checkLaserCollision(laser, monster) {
  let laserLeft = parseInt(laser.style.left)
  let laserTop = parseInt(laser.style.top)
  let laserBottom = laserTop - 20
  let monsterTop = parseInt(monster.style.top)
  let monsterBottom = monsterTop - 30
  let monsterLeft = parseInt(monster.style.left)
  if (laserLeft != 740 && laserLeft + 40 >= monsterLeft) {
    if ( (laserTop <= monsterTop && laserTop >= monsterBottom) ) {
      return true
    } else {
      return false
    }
  } else {
    return false
  }
}


function gameOver() {
  window.removeEventListener("keydown", letShipFly)
  clearInterval(monsterInterval)
  let monsters = document.querySelectorAll(".monster")
  monsters.forEach(monster => monster.remove())
  let lasers = document.querySelectorAll(".laser")
  lasers.forEach(laser => laser.remove())


  setTimeout(() => {
    if (health <= 0 ) {
      alert(`Game Over! You lose! You shot ${scoreCounter.innerText} Monsters!`)
      location.assign("endcredits.html");
    } else if (dead >= allMonsters) {
      alert(`Game Over! You won! You shot ${scoreCounter.innerText}  Monsters!`)
      location.assign("endcredits.html");
    }
    shooter.style.top = "180px"
    startButton.style.display = "block"
    instructions.style.display = "block"
    scoreCounter.innerText = 0
    health = 100
    healthIndicator.innerText = health
    monsterCount = 0
    dead = 0
  }, 1100)
}

function playGame() {
  startButton.style.display = 'none'
  instructions.style.display = 'none'
  window.addEventListener("keydown", letShipFly)
  monsterInterval = setInterval(() => {
    if (monsterCount < allMonsters) {
      monsterCount += 1
      createMonster()
    }
  }, 1200)
}
